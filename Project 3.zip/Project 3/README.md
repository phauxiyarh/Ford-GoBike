# (Ford GoBike Dataset)
## by (Umar Fauwzziyyah)


## Dataset

> This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area. The data was assessed and 6 qualityy issues were discovered and 1 tidiness isuess. it was resolved during the cleaning stage using the define-code and test process.


## Summary of Findings
>In this project 15 questions where explored in 3 ways <br>
>1. Univariate Exploration: we conducted 8 exploration question and visualized them
>2. Bivariate Exploration: we conducted 4 exploration question and visualized them
>3. Multivariate Exploration:we conducted 3 exploration question and visualized them

>In summary the bike service are used mostly during weekdays by the subscribers of the bike and it is most used during the weekend by the customers.
>Bike shared trip is less than 10%
>They are more subscribers than customers
>They Start and End Stations are common

## Key Insights for Presentation

> In the presentation we have 6 visualization slide showing <br>
>1. Visualization 1: Daily Bike Service
>2. Visualization 2: 10 Most Popular Start Station
>3. Visualization 3: 10 Most Popular End Station
>4. Visualization 4: User Type Comparisim
>5. Visualization 5: Weekly usage of bike based on the User Type
>6. Visualization 6: Amount of Time Spent based on User Type 